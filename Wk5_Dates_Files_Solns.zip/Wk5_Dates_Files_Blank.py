# -*- coding: utf-8 -*-
"""
@author: bstarly

#Read Section 1, Chapters 7-8 before attempting these exercises
"""

#1
#Write a program to get a list of dates between two dates entered 
#by the user in mm/dd/yyyy. 
#Check also if the first date is less than the second date.




#2
#Write a Program to Write The Given Strings to a File
#n1='\n'
#lines = 'Binil', n1, 'Starly', 'is', n1, 'teaching', n1, 'Python', n1, 'today'




#3
#Write a program that removes all empty lines from the attached 
#text file “SampleText.txt’ and copy the contents to a new file 
#without the empty lines.





#4
#For the contents in the file, count the number of words in a 
#text file and print the unique words in the file
#if on a MAC, read it as a .rtf file






#5
#Write a function CodeWord(filename) that reads a file ‘CNCFile.txt’ containing a large amount of text.
#For every instance of the word – CNC contained in the file, replace this word with the word – ‘XYZ’. Output this new text to another file – “CodedText.txt”.
#Also output the number of times the word – CNC appeared in the file to the console screen.







#Qn 6
#A: Extract the content of the zip file.
#B: Count the number of units sold
#C: max order sold by each country in the file and store the result in a dictionary
#D: Output a JSON file that lists each Item_Type and the countries that sold those items
#   as a dictionary, in the following format
#   ItemType: List of countries that sold that item 










