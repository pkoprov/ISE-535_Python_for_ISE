# -*- coding: utf-8 -*-
"""
@author: bstarly
"""

'''
This section covers sample exercises to help prepare for Exam 2.
It covers entirety of Essentials 1: Chapters 1 through 8

'''

'''
Qn1: Print the current working directory. Change the working directory to a new location
'''




'''
QN2:
A: Read the contents of a folder that contains files and sub-folders
B: Calculate the number of JPEG and JSON type files contained. No other file types to be read.
C: Print the file sizes of only the JPEG files contained in the folder
'''




'''
Qn3:
Save a JSON object as a PICKLE file
Retrieve the contents of the PICKLE file
  
'''
# More HELP: https://docs.python.org/3/library/pickle.html




'''
Qn 4:
A: Read a JSON file from the Samples JSON folder.
B: Read the 'volume' key from the JSON folder.
C: Increase the volume by 50%.
D: Resave the JSON file with the new value but every other value unchanged. You can rename the file.
'''        




'''
Qn5:
A: Read the contents of all the JSON files within the sample folder.
B: Read all of the volume values inside each of the json files.
C: Report on the total volume by summing all of these values.
'''

