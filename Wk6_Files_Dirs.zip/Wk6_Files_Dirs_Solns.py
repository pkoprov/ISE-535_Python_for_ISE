# -*- coding: utf-8 -*-
"""
@author: bstarly
"""

'''
This section covers sample exercises to help prepare for Exam 2.
It covers entirety of Essentials 1: Chapters 1 through 8

'''

import os

'''
Qn1: Print the current working directory. Change the working directory to a new location
'''

currentDir = os.getcwd()
print(currentDir)

newDir=r'E:\STARLY\NCSU_Data\Teaching\ISE535_Python_ISE\Exercises\Samples'
os.chdir(newDir)

currentDir = os.getcwd()
print(currentDir)

'''
QN2:
A: Read the contents of a folder that contains files and sub-folders
B: Calculate the number of JPEG and JSON type files contained. No other file types to be read.
C: Print the file sizes of only the JPEG files contained in the folder
'''
#List comprehension code to calculate the number of JPEG and JSON files in a given folder.
path=r"E:\STARLY\NCSU_Data\Teaching\ISE535_Python_ISE\Exercises\JSON"
jsonNameList = [pos_json for pos_json in os.listdir(path) if pos_json.endswith('.json')]

path=r"E:\STARLY\NCSU_Data\Teaching\ISE535_Python_ISE\Exercises\JPEG"
jpegNameList = [pos_jpeg for pos_jpeg in os.listdir(path) if pos_jpeg.endswith('.jpg')]

print(len(jsonNameList))
print(len(jpegNameList))


#Find the size of all the JPEGs contained in the given folder-sub-folder
def getfileInfo(path):
    fileNames=[]
    fileSizes=[]
    for root, dirs, files in os.walk(path):          
        for file in files:   
            if (".jpeg" in file or ".jpg" in file):
                fileNames.append(file[:-4])
                fSize=os.path.getsize(os.path.join(root, file))
                fileSizes.append(fSize/1024) #units in KBytes
            else:
                pass
    return fileNames, fileSizes

path=r"E:\STARLY\NCSU_Data\Teaching\ISE535_Python_ISE\Fall_2020\Class_Exercises\Week_7_Data"
fileNames, fileSizes = getfileInfo(path)

'''
Qn3:
Save a JSON object as a PICKLE file
Retrieve the contents of the PICKLE file
  
'''
# More HELP: https://docs.python.org/3/library/pickle.html
import pickle 

file = open('data.pkl', 'wb') 
pickle.dump(jsonNameList, file) 
file.close()    
    
with open("data.pkl", "rb") as openpkl:
    retrObj = pickle.load(openpkl)

print(retrObj)

'''
Qn 4:
A: Read a JSON file from the Samples JSON folder.
B: Read the 'volume' key from the JSON folder.
C: Increase the volume by 50%.
D: Resave the JSON file with the new value but every other value unchanged. You can rename the file.
'''        
import json
fileLoc=r'E:\STARLY\NCSU_Data\Teaching\ISE535_Python_ISE\Exercises\JSON\00a51dcb-276f-4529-b5e5-69a5f7fa27a3.json'
file = open(fileLoc,'r')
dataObj = json.load(file)
print(dataObj)

vol = float(dataObj['volume'])
print("The volume in the json file is:", vol)

vol = vol * 1.5
dataObj['volume'] = vol
print("New Data Object is", dataObj)

newLoc=r'E:\STARLY\NCSU_Data\Teaching\ISE535_Python_ISE\Exercises\JSON\00a51dcb-276f-4529-b5e5-69a5f7fa27a3_V2.json'
newfile = open(newLoc, 'w')
json.dump(dataObj, newfile)
newfile.close()

'''
Qn5:
A: Read the contents of all the JSON files within the sample folder.
B: Read all of the volume values inside each of the json files.
C: Report on the total volume by summing all of these values.
'''

import json
path=r"E:\STARLY\NCSU_Data\Teaching\ISE535_Python_ISE\Exercises\JSON"
jsonNameList = [pos_json for pos_json in os.listdir(path) if pos_json.endswith('.json')]
os.chdir(path)
print(os.getcwd())

vol = 0
for fileName in jsonNameList:
    with open(fileName, 'r') as file:
        dataObj = json.load(file)
        vol = vol + float(dataObj['volume'])

print("The total volume is: ", vol)
